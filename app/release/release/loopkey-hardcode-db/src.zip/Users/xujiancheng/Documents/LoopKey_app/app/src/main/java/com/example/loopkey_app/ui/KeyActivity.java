package com.example.loopkey_app.ui;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.loopkey_app.R;
import com.example.loopkey_app.crypto.ByteCompatNormalizer;
import com.example.loopkey_app.crypto.FragmentStorage;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class KeyActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_key);

        initializeApp();
    }

    // ... 省略其他程式碼

    private void initializeApp() {
        try {
            ByteCompatNormalizer.init(getApplicationContext());
        } catch (Exception e) {
            throw new NormalizerInitException("Normalizer init failed", e);
        }

        FragmentStorage storage;
        try {
            storage = new FragmentStorage(this);
        } catch (Exception e) {
            throw new StorageInitException("Storage init failed", e);
        }

        EditText inputKey = findViewById(R.id.editKey);
        setupButtons(storage, inputKey);
    }

    private static class NormalizerInitException extends RuntimeException {
        public NormalizerInitException(String message, Throwable cause) {
            super(message, cause);
        }
    }

    private static class StorageInitException extends RuntimeException {
        public StorageInitException(String message, Throwable cause) {
            super(message, cause);
        }
    }


    private void setupButtons(FragmentStorage storage, EditText inputKey) {
        findViewById(R.id.btnSave).setOnClickListener(v -> saveKey(storage, inputKey));
        findViewById(R.id.btnLoad).setOnClickListener(v -> loadKey(storage));
        findViewById(R.id.btnTest).setOnClickListener(v -> testIpInfo(storage));
        findViewById(R.id.btnBenchmark).setOnClickListener(v -> benchmarkApiCall(storage)); // 加入這一行
    }

    private void saveKey(FragmentStorage storage, EditText inputKey) {
        try {
            storage.savePlainKey(inputKey.getText().toString().getBytes());
            Toast.makeText(this, "Key 已儲存！", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Log.e("KeySave", "Save error", e);
        }
    }

    private void loadKey(FragmentStorage storage) {
        try {
            byte[] key = storage.loadPlainKey();
            Toast.makeText(this, "讀出 Key：" + new String(key), Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Log.e("KeyLoad", "Load error", e);
        }
    }

    private void testIpInfo(FragmentStorage storage) {
        new Thread(() -> {
            try {
                byte[] key = storage.loadPlainKey();
                String token = new String(key);
                String apiUrl = "https://ipinfo.io/json?token=" + token;
                HttpURLConnection conn = (HttpURLConnection) new URL(apiUrl).openConnection();
                conn.setRequestMethod("GET");

                int code = conn.getResponseCode();
                if (code == 200) {
                    handleSuccessfulResponse(conn);
                } else {
                    showToast("HTTP Error: " + code);
                }
            } catch (Exception e) {
                Log.e("IPinfo", "Error", e);
                showToast("Exception: " + e.getMessage());
            }
        }).start();
    }

    private void handleSuccessfulResponse(HttpURLConnection conn) throws Exception {
        try (InputStream in = conn.getInputStream(); ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) != -1) bos.write(buf, 0, n);

            String json = bos.toString("UTF-8");
            JSONObject obj = new JSONObject(json);
            String ip = obj.optString("ip", "N/A");

            runOnUiThread(() -> {
                Toast.makeText(this, "IP: " + ip, Toast.LENGTH_LONG).show();
                Log.i("IPinfo", json);
            });
        }
    }

    private void showToast(String message) {
        runOnUiThread(() -> Toast.makeText(this, message, Toast.LENGTH_SHORT).show());
    }

    private void benchmarkApiCall(FragmentStorage storage) {
        new Thread(() -> {
            final int rounds = 10;
            long[] latencies = new long[rounds];
            long[] memoryUsages = new long[rounds];

            for (int i = 0; i < rounds; i++) {
                try {
                    // 取出 token
                    byte[] key = storage.loadPlainKey();
                    String token = new String(key);

                    long startTime = System.currentTimeMillis();

                    String apiUrl = "https://ipinfo.io/json?token=" + token;
                    HttpURLConnection conn = (HttpURLConnection) new URL(apiUrl).openConnection();
                    conn.setRequestMethod("GET");

                    int code = conn.getResponseCode();
                    if (code == 200) {
                        try (InputStream in = conn.getInputStream(); ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
                            byte[] buf = new byte[4096];
                            int n;
                            while ((n = in.read(buf)) != -1) bos.write(buf, 0, n);
                            // 不需顯示結果，純測試效能
                        }
                    }

                    long endTime = System.currentTimeMillis();
                    latencies[i] = endTime - startTime;

                    // 強制 GC 再記憶體記錄（較乾淨）
                    Runtime runtime = Runtime.getRuntime();
                    runtime.gc();
                    long usedMemKB = (runtime.totalMemory() - runtime.freeMemory()) / 1024L;
                    memoryUsages[i] = usedMemKB;

                    Log.i("Benchmark", "第 " + (i + 1) + " 次：延遲 " + latencies[i] + " ms, 記憶體 " + memoryUsages[i] + " KB");

                    Thread.sleep(500); // 避免打太快被伺服器限制
                } catch (Exception e) {
                    Log.e("Benchmark", "第 " + (i + 1) + " 次錯誤", e);
                }
            }

            long totalLatency = 0, totalMemory = 0;
            for (int i = 0; i < rounds; i++) {
                totalLatency += latencies[i];
                totalMemory += memoryUsages[i];
            }

            long avgLatency = totalLatency / rounds;
            long avgMemory = totalMemory / rounds;

            Log.i("Benchmark", "✅ 完成：平均延遲 " + avgLatency + " ms, 平均記憶體 " + avgMemory + " KB");

            runOnUiThread(() -> Toast.makeText(this,
                    "完成！平均延遲: " + avgLatency + " ms\n平均記憶體: " + avgMemory + " KB", Toast.LENGTH_LONG).show());
        }).start();
    }


}
