package com.example.loopkey_app.crypto;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;

import java.nio.ByteBuffer;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * FragmentStorage – stores user‑supplied key by:
 *  (1) ByteCompatNormalizer.pack() (bit‑level obfuscation in native)
 *  (2) hardware KeyStore AES‑GCM encryption
 *  (3) random fragmentation + EncryptedSharedPreferences
 *
 * loadPlainKey() performs the exact reverse.
 */
public class FragmentStorage {

    private static final String PREF_FILE   = "frag_store";
    private static final SecureRandom RND   = new SecureRandom();
    private static final int GCM_TAG_BITS   = 128;   // 128‑bit tag for AES‑GCM

    private final Context ctx;
    private final SecretKey masterKey;      // hardware/soft keystore key
    private final MasterKey prefMasterKey;  // Jetpack Security key for SharedPrefs

    public FragmentStorage(Context ctx) throws Exception {
        this.ctx = ctx.getApplicationContext();

        // ① prepare keystore key
        this.masterKey     = KeyStoreHelper.provideMasterKey(this.ctx);

        // ② prepare EncryptedSharedPreferences master key
        this.prefMasterKey = new MasterKey.Builder(this.ctx)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build();

        // ③ load native normalizer (formerly LoopReconstructor)
        ByteCompatNormalizer.init(this.ctx);
    }

    /* =====================  Public  ===================== */

    /** Persist user‑entered clear key (any length) */
    public void savePlainKey(byte[] plain) throws Exception {
        // L4 obfuscation – native pack()
        byte[] pre = ByteCompatNormalizer.pack(plain);

        // L3 AES‑GCM with hardware keystore (auto‑generate IV)
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, masterKey);
        byte[] iv         = cipher.getIV();
        byte[] cipherText = cipher.doFinal(pre);

        // L2 random fragmentation (4‑8 bytes) + offset tag
        List<Fragment> fragments = splitRandomWithOffset(cipherText, 4, 8);

        // L1 write to EncryptedSharedPreferences
        SharedPreferences sp = getPref();
        SharedPreferences.Editor ed = sp.edit();
        ed.clear();
        for (Fragment f : fragments) {
            ed.putString("frag_" + f.offset,
                    Base64.encodeToString(f.bytes, Base64.NO_WRAP));
        }
        ed.putString("aes_iv", Base64.encodeToString(iv, Base64.NO_WRAP));
        ed.apply();
    }

    /** Load and restore clear key */
    public byte[] loadPlainKey() throws Exception {
        SharedPreferences sp = getPref();

        // ① read & sort fragments by offset
        Map<String, ?> all = sp.getAll();
        TreeMap<Integer, byte[]> sorted = new TreeMap<>();
        for (Map.Entry<String, ?> e : all.entrySet()) {
            String k = e.getKey();
            if (k.startsWith("frag_")) {
                int offset = Integer.parseInt(k.substring(5));
                sorted.put(offset, Base64.decode((String) e.getValue(), Base64.NO_WRAP));
            }
        }
        byte[] cipherText = concat(new ArrayList<>(sorted.values()));
        byte[] iv = Base64.decode(sp.getString("aes_iv", ""), Base64.NO_WRAP);

        // ② AES‑GCM decrypt via keystore
        Cipher dcipher = Cipher.getInstance("AES/GCM/NoPadding");
        dcipher.init(Cipher.DECRYPT_MODE, masterKey, new GCMParameterSpec(GCM_TAG_BITS, iv));
        byte[] inter = dcipher.doFinal(cipherText);

        // ③ native unpack() → clear key
        return ByteCompatNormalizer.unpack(inter);
    }

    /* =====================  Internals  ===================== */

    private SharedPreferences getPref() throws Exception {
        return EncryptedSharedPreferences.create(
                ctx,
                PREF_FILE,
                prefMasterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        );
    }

    /** fragment structure */
    private static class Fragment {
        final int offset;
        final byte[] bytes;
        Fragment(int o, byte[] b) { offset = o; bytes = b; }
    }

    private static List<Fragment> splitRandomWithOffset(byte[] src, int min, int max) {
        List<Fragment> out = new ArrayList<>();
        int idx = 0;
        while (idx < src.length) {
            int part = Math.min(src.length - idx, min + RND.nextInt(max - min + 1));
            byte[] frag = new byte[part];
            System.arraycopy(src, idx, frag, 0, part);
            out.add(new Fragment(idx, frag));
            idx += part;
        }
        return out;
    }

    private static byte[] concat(List<byte[]> parts) {
        int total = parts.stream().mapToInt(p -> p.length).sum();
        ByteBuffer buf = ByteBuffer.allocate(total);
        for (byte[] p : parts) buf.put(p);
        return buf.array();
    }

    // 定義專屬例外
    public class StorageInitException extends RuntimeException {
        public StorageInitException(String message, Throwable cause) {
            super(message, cause);
        }
    }

}
