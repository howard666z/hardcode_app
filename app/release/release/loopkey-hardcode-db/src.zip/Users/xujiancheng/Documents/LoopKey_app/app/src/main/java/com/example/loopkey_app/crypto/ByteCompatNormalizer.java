package com.example.loopkey_app.crypto;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.util.Log;

import java.security.MessageDigest;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public final class ByteCompatNormalizer {

    private ByteCompatNormalizer() {
        // Prevent instantiation
    }

    private static SecretKeySpec secretKey;
    private static boolean ready = false;

    public static synchronized void init(Context ctx) throws NormalizerInitException {
        if (ready) return;

        try {
            byte[] key = deriveKeyFromApk(ctx);
            secretKey = new SecretKeySpec(key, "AES");
            ready = true;
            Log.d("ByteCompatNorm", "Java normalizer ready");
        } catch (Exception e) {
            throw new NormalizerInitException("Failed to initialize ByteCompatNormalizer", e);
        }
    }

    public static byte[] pack(byte[] plaintext) {
        ensure();
        try {
            byte[] iv = new byte[12];
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, new GCMParameterSpec(128, iv));
            byte[] ciphertext = cipher.doFinal(plaintext);

            byte[] result = new byte[12 + ciphertext.length];
            System.arraycopy(iv, 0, result, 0, 12);
            System.arraycopy(ciphertext, 0, result, 12, ciphertext.length);
            return result;
        } catch (Exception e) {
            throw new EncryptionException("Encryption failed", e);
        }
    }

    public static byte[] unpack(byte[] ciphertext) {
        ensure();
        try {
            byte[] iv = Arrays.copyOfRange(ciphertext, 0, 12);
            byte[] enc = Arrays.copyOfRange(ciphertext, 12, ciphertext.length);

            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, secretKey, new GCMParameterSpec(128, iv));
            return cipher.doFinal(enc);
        } catch (Exception e) {
            throw new DecryptionException("Decryption failed", e);
        }
    }

    private static void ensure() {
        if (!ready) throw new IllegalStateException("ByteCompatNormalizer.init() 未呼叫");
    }

    private static byte[] deriveKeyFromApk(Context ctx) throws Exception {
        PackageInfo p = ctx.getPackageManager()
                .getPackageInfo(ctx.getPackageName(), PackageManager.GET_SIGNING_CERTIFICATES);
        byte[] certBytes = p.signingInfo.getApkContentsSigners()[0].toByteArray();
        byte[] sha = MessageDigest.getInstance("SHA-256").digest(certBytes);
        return Arrays.copyOf(sha, 32);
    }

    public static class NormalizerInitException extends RuntimeException {
        public NormalizerInitException(String message, Throwable cause) {
            super(message, cause);
        }
    }

    public static class EncryptionException extends RuntimeException {
        public EncryptionException(String message, Throwable cause) {
            super(message, cause);
        }
    }

    public static class DecryptionException extends RuntimeException {
        public DecryptionException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
