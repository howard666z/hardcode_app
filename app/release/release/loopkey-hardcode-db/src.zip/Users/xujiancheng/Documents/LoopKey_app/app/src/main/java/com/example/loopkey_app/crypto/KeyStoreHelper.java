package com.example.loopkey_app.crypto;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.security.keystore.StrongBoxUnavailableException;

import java.security.KeyStore;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

public final class KeyStoreHelper {

    private static final String ANDROID_KEYSTORE = "AndroidKeyStore";
    private static final String MASTER_ALIAS     = "loop_obf_master";
    private static final String GENERIC_TYPE = "generic";

    private KeyStoreHelper() {}   // 工具類，不給實例化

    /** 回傳硬體保護 AES‑GCM 金鑰；真機盡量放 StrongBox，失敗就退回 TEE；模擬器永遠走軟體。 */
    public static SecretKey provideMasterKey(Context ctx) throws Exception {

        // -------- 0. 如果已經生成過就直接拿 --------
        KeyStore ks = KeyStore.getInstance(ANDROID_KEYSTORE);
        ks.load(null);
        if (ks.containsAlias(MASTER_ALIAS))
            return (SecretKey) ks.getKey(MASTER_ALIAS, /*password*/ null);

        // -------- 1. 準備 Builder --------
        KeyGenParameterSpec.Builder specBuilder = new KeyGenParameterSpec.Builder(
                MASTER_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE);

        KeyGenerator kg = KeyGenerator.getInstance(
                KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE);

        // -------- 2. 判斷是否要嘗試 StrongBox --------
        boolean isEmulator = isRunningOnEmulator();
        boolean strongBoxFeature =
                ctx.getPackageManager().hasSystemFeature(
                        PackageManager.FEATURE_STRONGBOX_KEYSTORE);

        if (!isEmulator && strongBoxFeature) {
            try {
                // (2‑1) 真機且宣告支援 → 先要求 StrongBox
                specBuilder.setIsStrongBoxBacked(true);
                kg.init(specBuilder.build());
                return kg.generateKey();              // ← 成功落在 StrongBox
            } catch (StrongBoxUnavailableException e) {
                // (2‑2) 裝置宣告但實際不可用 (停用 / 故障) → fall through
            }
        }

        // -------- 3. Fallback：改用一般 TEE 或軟體 Keystore --------
        specBuilder.setIsStrongBoxBacked(false);
        kg.init(specBuilder.build());
        return kg.generateKey();
    }

    /* ============ Helper ============ */

    /** 最常見的幾種 AVD / Genymotion 參數，可依需要再增補 */
    private static boolean isRunningOnEmulator() {
        return Build.FINGERPRINT.startsWith(GENERIC_TYPE)
                || Build.FINGERPRINT.startsWith("unknown")
                || Build.MODEL.contains("google_sdk")
                || Build.MODEL.contains("Emulator")
                || Build.MODEL.contains("Android SDK built for x86")
                || Build.MANUFACTURER.contains("Genymotion")
                || (Build.BRAND.startsWith(GENERIC_TYPE) && Build.DEVICE.startsWith(GENERIC_TYPE));
    }
}
